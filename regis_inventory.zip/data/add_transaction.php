<?php 

if(isset($_POST['custName'])){
	$custName = $_POST['custName'];
	$tender = $_POST['tender'];
	$totalOrder = $_POST['totalOrder'];
	$change = $_POST['change'];
	
}//end

